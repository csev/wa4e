<?php // Do not put any HTML above this line

include_once("../config.php");

session_start();
unset($_SESSION['name']); // To Log the user out
unset($_SESSION['user_id']); // To Log the user out
header('Location: index.php');
